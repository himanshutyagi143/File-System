<?php
session_start();
require_once 'config/database.php';

$user_email = $_SESSION['uemail'];
#################################################################################################
if($_SESSION['uemail'] == '')
{
    header("location: index.php?id=login");
}

if(@$_GET['id'] == 'logout')
{
    session_destroy();
    header("location: index.php?id=login");
}
###################################################################################################




###################################################################################################
if(isset($_POST['upload']))
{
    // print_r($_FILES);
    $size = $_FILES['images']['size']/1048576;
    $type = $_FILES['images']['type'];
    $arr = array("image/png","image/jpeg");
    if($type == "image/png" OR $type == "image/jpeg")
    {
        if($size <= 2 )
        {
            $temp = $_FILES['images']['tmp_name'];
        $name = $_FILES['images']['name'];
            $query = "INSERT INTO `image` (`id`, `name`, `width`, `height`) VALUES (NULL, '$name', '305px', '280px');";
            $data = mysqli_query($dbcon,$query);

        
        move_uploaded_file($temp,"image/$name");
        $msg = "File Uploaded";
        }
        else
        {
            $msg = "Image Size must be less than 2 mb";
        }
    }
    elseif($type != "image/jpeg")
    {
        $msg = "Image should be in jpg or png";
    }
    elseif($type != "image/png")
    {
        $msg = "Image should be in jpg or png";
    }
    else
    {
        $msg = "Image should be in jpg or png";
        $msg = "Image Size must be less than 2 mb";
    }
}

###################################################################################################
?>

<!--------------------------------------------------------------------------------------------------------->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Wallpaper</title>
</head>
<body>

<div style="width: 70%; margin: auto;">

<div class="head" style="text-align: none;">
<div style="float:left; width: 49%; margin-top: 1%;">
<form method="post" enctype="multipart/form-data">
<input type="file" name="images">
<input type="submit" name="upload" value="Upload">
<p style="color: red;"><?php echo @$msg; ?></p>
</form>

</div>
<div style="float: right; margin-top: 1%; width: 50%;"><a href="?id=logout">LOGOUT</a></div>

<div style="clear: both;"></div>
</div>
<!--------------------------------------------------------------------------------------------------------->

<!--------------------------------------------------------------------------------------------------------->
<div class="mid">
<?php
##########################################
$query="SELECT * FROM `image`";
$data = mysqli_query($dbcon,$query);
##########################################
?>
<div class="img_cont">
    <?php
    while($res = mysqli_fetch_assoc($data))
    { 
        ?>
<img src="image/<?php echo $res['name']; ?>" width="<?php echo $res['width']; ?>" height="<?php echo $res['height']; ?>" style="margin-left: 2px;">
<?php
    }
    ?>

</div>


</div>
<!--------------------------------------------------------------------------------------------------------->

</div>

</body>
</html>