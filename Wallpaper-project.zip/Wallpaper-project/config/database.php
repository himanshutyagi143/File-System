<?php
define("dbhost","localhost");
define("dbuser","root");
define("dbpass","");
define("dbname","wallpaper");
$dbcon = mysqli_connect(dbhost,dbuser,dbpass,dbname);


?>