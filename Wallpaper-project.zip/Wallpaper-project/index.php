


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Wallpaper</title>
</head>
<body>

<div style="width: 70%; margin: auto;">

<div class="head">
<p><a href="?id=login">LOGIN</a></p>
</div>

<div class="mid">
<?php
if(@$_GET['id'] == 'login')
{
    require_once 'mid.php';
}

?>
</div>


</div>

</body>
</html>