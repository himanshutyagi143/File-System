<?php
session_start();
require_once 'config/database.php';
if(isset($_POST['login']))
{
    extract($_POST);
    $query = "SELECT * FROM `user` WHERE `email` = '$uemail' and `pass` = '$upass'";
    $data = mysqli_query($dbcon,$query);
    $res = mysqli_fetch_assoc($data);
    
    if(empty($uemail) && empty($upass))
    {
        $msg = "Please Enter Email & Password";
    }
    else if(empty($uemail))
    {
        $msg ="Please Enter Your Email";
    }
    else if(empty($upass))
    {
        $msg ="Please Enter Your Password";
    }
    // checking id and password in database
    else
    {
    if($res['email'] == $uemail && $res['pass'] == $upass )
    {
        $_SESSION['uemail'] = $res['email'];
        header("location: upload.php");
    }
    else
    {
        $msg = "Id & Password not match"; 
    }
}}

?>

<div style="text-align: center; margin-top: 5%;">
<form method="post">
<label for="uemail">Username</label>
<input type="email" name="uemail" id="uemail">
<br><br>
<label for="upass">Password</label>
<input type="password" name="upass" id="upass">
<br><br>
<input type="submit" name="login" value="LOGIN" style="width: 26%; padding: 8px; background-color: teal; color: #fff;">
</form>
<br>
<p style="text-align: center; color: red;"><?php echo @$msg; ?></p>
</div>